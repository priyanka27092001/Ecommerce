package com.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.model.User;

public class UserDao<stmnt> {
	private Connection con;
	private String query;
	private PreparedStatement pst;
	private Statement stmnt;
	private ResultSet rs;
	
	public UserDao(Connection con) {
		
		this.con = con;
	}
	
	public User userLogin (String email, String password) {
		User user = null;
		try {
			query="select * from users where email=? and password=?";
			pst = this.con.prepareStatement(query);
			pst.setString(1, email);
			pst.setString(2, password);
			rs=pst.executeQuery();
			
			if(rs.next()) {
				user = new User();
				user.setId(rs.getInt("id"));
				user.setName(rs.getString("name"));
				user.setEmail(rs.getString("email"));
			}
		}catch(Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		return user;
	}
	
	

public void saveUser(String name, String email, String password) {
	// TODO Auto-generated method stub
	User user=null;
	try {
		query="select max(id) from users";
		stmnt=this.con.createStatement();
		rs = stmnt.executeQuery(query);
		rs.absolute(1);
		int id=rs.getInt(1);
		System.out.println(id);
		String insertQuery="insert into users values (?,?,?,?)";
		pst=con.prepareStatement(insertQuery);  
		pst.setInt(1,id+1);
		pst.setString(2,name);
		pst.setString(3, email);
		pst.setString(4, password);
		pst.executeUpdate();
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}
	

